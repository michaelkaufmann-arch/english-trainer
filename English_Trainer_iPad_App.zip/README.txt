English Trainer – iPad App-Version

Für die Installation auf dem iPad muss diese Version über eine HTTPS-Webadresse geöffnet werden.
Dann in Safari: Teilen -> Zum Home-Bildschirm.

Die Dateien im Ordner gehören zusammen. Nicht einzeln umbenennen.
